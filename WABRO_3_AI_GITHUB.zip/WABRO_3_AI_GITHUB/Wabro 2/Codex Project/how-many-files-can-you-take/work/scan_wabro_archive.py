#!/usr/bin/env python3
from __future__ import annotations

import csv
import os
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

ROOTS = [
    Path("/Users/lukewabro"),
    Path("/Volumes/Luke backups"),
]

OUT_DIR = Path("/Users/lukewabro/Documents/Codex/2026-06-01/how-many-files-can-you-take/outputs")

KEYWORDS = [
    "wabro",
    "assemblage",
    "eeg",
    "muse",
    "snare",
    "backwards",
    "signals",
    "signal",
    "neuro",
    "bitwig",
    "ableton",
    "touchdesigner",
    "plugdata",
    "pure data",
    "max",
    "osc",
    "midi",
]

CREATIVE_EXTS = {
    ".bwproject",
    ".bitwig-project",
    ".als",
    ".adg",
    ".adv",
    ".amxd",
    ".maxpat",
    ".maxproj",
    ".pd",
    ".toe",
    ".blend",
    ".wav",
    ".aif",
    ".aiff",
    ".mp3",
    ".flac",
    ".mov",
    ".mp4",
    ".m4v",
    ".docx",
    ".doc",
    ".pdf",
    ".txt",
    ".md",
    ".rtf",
    ".zip",
    ".7z",
    ".rar",
}

SKIP_DIR_NAMES = {
    ".Trash",
    ".Trashes",
    ".Spotlight-V100",
    ".DocumentRevisions-V100",
    ".TemporaryItems",
    ".fseventsd",
    "Keychains",
    "Cookies",
    "Safari",
    "Messages",
    "Mail",
    "HTTPStorages",
    "Caches",
    "DoNotDisturb",
    "Finance",
    "FinanceBackup",
}

MAX_HITS_PER_KEYWORD = 350
MAX_CREATIVE_ROWS = 12000


def stamp(ts: float) -> str:
    try:
        return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return ""


def root_label(path: Path) -> str:
    text = str(path)
    if text.startswith("/Volumes/Luke backups"):
        return "Luke backups"
    if text.startswith("/Users/lukewabro"):
        return "MacBook user"
    return "Other"


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    ext_counts: Counter[str] = Counter()
    root_counts: Counter[str] = Counter()
    keyword_counts: Counter[str] = Counter()
    skipped: Counter[str] = Counter()
    creative_rows = []
    keyword_rows = []
    top_large = []
    project_rows = []
    scanned = 0

    project_exts = {".bwproject", ".als", ".amxd", ".maxpat", ".pd", ".toe", ".blend"}

    for root in ROOTS:
        for dirpath, dirnames, filenames in os.walk(root, topdown=True, onerror=lambda e: skipped.update([getattr(e, "filename", "unknown")])):
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIR_NAMES and not d.startswith("__MACOSX")]
            current = Path(dirpath)
            for name in filenames:
                if name == ".DS_Store" or name.startswith("._"):
                    continue
                path = current / name
                scanned += 1
                ext = path.suffix.lower() or "[no extension]"
                ext_counts[ext] += 1
                root_counts[root_label(path)] += 1
                lower_path = str(path).lower()

                try:
                    st = path.stat()
                except OSError as exc:
                    skipped.update([f"{type(exc).__name__}: {path}"])
                    continue

                row = {
                    "modified": stamp(st.st_mtime),
                    "size_bytes": st.st_size,
                    "ext": ext,
                    "path": str(path),
                }

                if ext in CREATIVE_EXTS and len(creative_rows) < MAX_CREATIVE_ROWS:
                    creative_rows.append(row)

                if ext in project_exts:
                    project_rows.append(row)

                if st.st_size > 250_000_000:
                    top_large.append(row)

                for kw in KEYWORDS:
                    if kw in lower_path:
                        keyword_counts[kw] += 1
                        if len([r for r in keyword_rows if r["keyword"] == kw]) < MAX_HITS_PER_KEYWORD:
                            hit = row.copy()
                            hit["keyword"] = kw
                            keyword_rows.append(hit)

    top_large.sort(key=lambda r: r["size_bytes"], reverse=True)
    project_rows.sort(key=lambda r: (r["ext"], r["path"]))
    creative_rows.sort(key=lambda r: (r["ext"], r["path"]))
    keyword_rows.sort(key=lambda r: (r["keyword"], r["path"]))

    with (OUT_DIR / "wabro_scan_creative_files.tsv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["modified", "size_bytes", "ext", "path"], delimiter="\t")
        writer.writeheader()
        writer.writerows(creative_rows)

    with (OUT_DIR / "wabro_scan_keyword_hits.tsv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["keyword", "modified", "size_bytes", "ext", "path"], delimiter="\t")
        writer.writeheader()
        writer.writerows(keyword_rows)

    with (OUT_DIR / "wabro_scan_project_files.tsv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["modified", "size_bytes", "ext", "path"], delimiter="\t")
        writer.writeheader()
        writer.writerows(project_rows)

    lines = []
    lines.append("# WABRO Read-Only Archive Scan")
    lines.append("")
    lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append("")
    lines.append("## Roots Scanned")
    for root in ROOTS:
        lines.append(f"- `{root}`")
    lines.append("")
    lines.append("## Scope Notes")
    lines.append("- Read-only filename/stat scan.")
    lines.append("- Source files were not modified.")
    lines.append("- Protected/system-private folders such as Keychains, Mail, Messages, caches, Trash, Spotlight, and macOS revision stores were skipped or denied.")
    lines.append("")
    lines.append("## Totals")
    lines.append(f"- Files scanned: `{scanned:,}`")
    for label, count in root_counts.most_common():
        lines.append(f"- {label}: `{count:,}` files")
    lines.append("")
    lines.append("## Extension Counts")
    for ext, count in ext_counts.most_common(40):
        lines.append(f"- `{ext}`: `{count:,}`")
    lines.append("")
    lines.append("## Project File Counts")
    project_counter = Counter(r["ext"] for r in project_rows)
    for ext, count in project_counter.most_common():
        lines.append(f"- `{ext}`: `{count:,}`")
    lines.append("")
    lines.append("## Keyword Hits")
    for kw, count in keyword_counts.most_common():
        lines.append(f"- `{kw}`: `{count:,}`")
    lines.append("")
    lines.append("## Largest Creative/Media Files Over 250MB")
    for row in top_large[:50]:
        mb = row["size_bytes"] / 1_000_000
        lines.append(f"- `{mb:,.1f} MB` `{row['modified']}` {row['path']}")
    lines.append("")
    lines.append("## Output Tables")
    lines.append("- `wabro_scan_creative_files.tsv`")
    lines.append("- `wabro_scan_keyword_hits.tsv`")
    lines.append("- `wabro_scan_project_files.tsv`")

    (OUT_DIR / "wabro_read_only_archive_scan.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(f"Scanned {scanned:,} files")
    print(f"Wrote {OUT_DIR / 'wabro_read_only_archive_scan.md'}")
    print(f"Project files: {len(project_rows):,}")
    print(f"Keyword hit rows: {len(keyword_rows):,}")
    print(f"Creative rows: {len(creative_rows):,}")


if __name__ == "__main__":
    main()

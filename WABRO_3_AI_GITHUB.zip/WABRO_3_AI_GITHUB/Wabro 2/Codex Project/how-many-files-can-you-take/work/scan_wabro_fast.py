#!/usr/bin/env python3
from __future__ import annotations

import csv
import os
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

ROOTS = [
    Path("/Users/lukewabro/Desktop"),
    Path("/Users/lukewabro/Documents"),
    Path("/Users/lukewabro/Downloads"),
    Path("/Users/lukewabro/Music"),
    Path("/Users/lukewabro/Movies"),
    Path("/Users/lukewabro/iCloud Drive (Archive)"),
    Path("/Volumes/Luke backups"),
]

OUT_DIR = Path("/Users/lukewabro/Documents/Codex/2026-06-01/how-many-files-can-you-take/outputs")
KEYWORDS = ["wabro", "assemblage", "eeg", "muse", "snare", "backwards", "signals", "signal", "neuro", "bitwig", "ableton", "touchdesigner", "plugdata", "osc", "midi"]
PROJECT_EXTS = {".bwproject", ".als", ".amxd", ".maxpat", ".pd", ".toe", ".blend"}
CREATIVE_EXTS = PROJECT_EXTS | {".bitwig-project", ".wav", ".aif", ".aiff", ".mp3", ".flac", ".mov", ".mp4", ".m4v", ".docx", ".doc", ".pdf", ".txt", ".md", ".rtf", ".zip", ".7z", ".rar"}
SKIP_DIR_NAMES = {".Trash", ".Trashes", ".Spotlight-V100", ".DocumentRevisions-V100", ".TemporaryItems", ".fseventsd", "__MACOSX", "node_modules", ".git"}


def stamp(ts: float) -> str:
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    ext_counts = Counter()
    kw_counts = Counter()
    project_rows = []
    creative_rows = []
    kw_rows = []
    root_counts = Counter()
    skipped = Counter()
    scanned = 0

    kw_saved = defaultdict(int)

    for root in ROOTS:
        if not root.exists():
            continue
        for dirpath, dirnames, filenames in os.walk(root, topdown=True, onerror=lambda e: skipped.update([getattr(e, "filename", "unknown")])):
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIR_NAMES]
            for name in filenames:
                if name == ".DS_Store" or name.startswith("._"):
                    continue
                path = Path(dirpath) / name
                scanned += 1
                try:
                    st = path.stat()
                except OSError:
                    skipped.update(["stat denied"])
                    continue
                ext = path.suffix.lower() or "[no extension]"
                ext_counts[ext] += 1
                root_counts[str(root)] += 1
                row = {"modified": stamp(st.st_mtime), "size_bytes": st.st_size, "ext": ext, "path": str(path)}
                lower = str(path).lower()
                if ext in PROJECT_EXTS:
                    project_rows.append(row)
                if ext in CREATIVE_EXTS:
                    creative_rows.append(row)
                for kw in KEYWORDS:
                    if kw in lower:
                        kw_counts[kw] += 1
                        if kw_saved[kw] < 500:
                            hit = dict(row)
                            hit["keyword"] = kw
                            kw_rows.append(hit)
                            kw_saved[kw] += 1

    project_rows.sort(key=lambda r: (r["ext"], r["path"]))
    creative_rows.sort(key=lambda r: (r["ext"], r["path"]))
    kw_rows.sort(key=lambda r: (r["keyword"], r["path"]))

    for filename, rows, fields in [
        ("wabro_fast_project_files.tsv", project_rows, ["modified", "size_bytes", "ext", "path"]),
        ("wabro_fast_creative_files.tsv", creative_rows, ["modified", "size_bytes", "ext", "path"]),
        ("wabro_fast_keyword_hits.tsv", kw_rows, ["keyword", "modified", "size_bytes", "ext", "path"]),
    ]:
        with (OUT_DIR / filename).open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields, delimiter="\t")
            writer.writeheader()
            writer.writerows(rows)

    lines = [
        "# WABRO Fast Creative Scan",
        "",
        f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "",
        "## Totals",
        f"- Files scanned: `{scanned:,}`",
        f"- Creative files indexed: `{len(creative_rows):,}`",
        f"- Project files indexed: `{len(project_rows):,}`",
        f"- Keyword hit rows saved: `{len(kw_rows):,}`",
        "",
        "## Root Counts",
    ]
    for root, count in root_counts.most_common():
        lines.append(f"- `{root}`: `{count:,}`")
    lines.append("")
    lines.append("## Project Extension Counts")
    pc = Counter(r["ext"] for r in project_rows)
    for ext, count in pc.most_common():
        lines.append(f"- `{ext}`: `{count:,}`")
    lines.append("")
    lines.append("## Keyword Counts")
    for kw, count in kw_counts.most_common():
        lines.append(f"- `{kw}`: `{count:,}`")
    lines.append("")
    lines.append("## Top Extension Counts")
    for ext, count in ext_counts.most_common(40):
        lines.append(f"- `{ext}`: `{count:,}`")
    lines.append("")
    lines.append("## Output Tables")
    lines.append("- `wabro_fast_project_files.tsv`")
    lines.append("- `wabro_fast_creative_files.tsv`")
    lines.append("- `wabro_fast_keyword_hits.tsv`")
    (OUT_DIR / "wabro_fast_creative_scan.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(f"Scanned {scanned:,} files")
    print(f"Creative files: {len(creative_rows):,}")
    print(f"Project files: {len(project_rows):,}")
    print(f"Wrote {OUT_DIR / 'wabro_fast_creative_scan.md'}")


if __name__ == "__main__":
    main()

#!/bin/bash
set -e

echo "Optional setup for WABRO transcription"
echo "This installs ffmpeg through Homebrew and openai-whisper through pip."
echo "Press Ctrl+C now if you do not want to install anything."
sleep 5

if ! command -v brew >/dev/null 2>&1; then
  echo "Homebrew not found. Install it from https://brew.sh first."
  exit 1
fi

brew install ffmpeg
python3 -m pip install -U openai-whisper

echo "Done. Now run: ./scripts/run_wabro_full_project.command"

#!/bin/bash
set -e
cd "$(dirname "$0")/.."
python3 scripts/wabro_full_project_export.py

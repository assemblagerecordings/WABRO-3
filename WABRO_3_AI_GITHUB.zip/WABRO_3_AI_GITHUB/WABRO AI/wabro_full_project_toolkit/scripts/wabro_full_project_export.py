#!/usr/bin/env python3
"""
WABRO Full Project Exporter

Creates text data for ChatGPT from local WABRO-related sources:
- Music Projects on Lukes backups
- locally synced Google Drive videos
- Bitwig projects
- PlugData / Pure Data / Max patches
- public social pages
- optional local Whisper transcription

No passwords, cookies, browser databases, private messages, Keychains, or hidden login sessions are used.
"""

from __future__ import annotations

import csv
import datetime as dt
import html
import json
import os
import re
import shutil
import subprocess
import sys
import urllib.parse
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional
from html.parser import HTMLParser

HOME = Path.home()
DESKTOP = HOME / "Desktop"
EXPORT = DESKTOP / "WABRO_FULL_PROJECT_EXPORT"

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_DIR = SCRIPT_DIR.parent
SOCIAL_URLS_FILE = PROJECT_DIR / "config" / "social_urls.txt"

# Keep this focused on WABRO / creative data.
RELEVANT_EXTS = {
    ".bwproject", ".bwpreset", ".bwclip",
    ".als", ".amxd", ".maxpat", ".pd",
    ".wav", ".aif", ".aiff", ".mp3", ".flac", ".m4a", ".aac",
    ".mp4", ".mov", ".m4v", ".webm", ".mkv", ".avi",
    ".mid", ".midi",
    ".txt", ".md", ".json", ".xml", ".csv", ".tsv",
    ".docx", ".pdf", ".pptx", ".xlsx",
}

VIDEO_EXTS = {".mp4", ".mov", ".m4v", ".webm", ".mkv", ".avi"}
AUDIO_EXTS = {".wav", ".aif", ".aiff", ".mp3", ".flac", ".m4a", ".aac"}
PATCH_EXTS = {".pd", ".maxpat", ".amxd"}
TEXT_EXTS = {".txt", ".md", ".json", ".xml", ".csv", ".tsv"}

EXCLUDE_PARTS = {
    "Library/Keychains",
    "Library/Mail",
    "Library/Messages",
    "Library/Caches",
    "Library/Safari",
    "Library/Application Support/Google/Chrome",
    "Library/Application Support/Firefox",
    ".Trash",
    "node_modules",
    ".git/objects",
}

DRIVE_CANDIDATES = [
    Path("/Volumes/Lukes backups"),
    Path("/Volumes/Luke backups"),
    Path("/Volumes/Lukes Backups"),
    Path("/Volumes/Luke Backups"),
]

MUSIC_PROJECT_FOLDER_NAMES = [
    "Music Projects", "Music projects", "music projects", "MUSIC PROJECTS", "MusicProjects",
]


def now_stamp() -> str:
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def safe_print(msg: str = "") -> None:
    print(msg, flush=True)


def ensure_dirs() -> None:
    for sub in [
        "indexes", "social/html", "social/text", "social/json",
        "bitwig", "eeg", "videos", "transcripts", "audio_extracts", "logs",
    ]:
        (EXPORT / sub).mkdir(parents=True, exist_ok=True)


def path_is_excluded(path: Path) -> bool:
    s = str(path)
    return any(part in s for part in EXCLUDE_PARTS)


def stat_row(path: Path) -> list[str]:
    try:
        st = path.stat()
        modified = dt.datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S")
        return [modified, str(st.st_size), str(path)]
    except Exception as exc:
        return ["ERROR", "0", f"{path} :: {exc}"]


def write_tsv(path: Path, rows: Iterable[list[str]], header: Optional[list[str]] = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.writer(f, delimiter="\t")
        if header:
            w.writerow(header)
        for row in rows:
            w.writerow(row)


def find_backup_drive() -> Optional[Path]:
    for p in DRIVE_CANDIDATES:
        if p.exists():
            return p
    return None


def find_music_projects(drive: Optional[Path]) -> Optional[Path]:
    if not drive:
        return None
    for name in MUSIC_PROJECT_FOLDER_NAMES:
        p = drive / name
        if p.exists():
            return p
    # Controlled search, shallow.
    try:
        for p in drive.rglob("*"):
            if p.is_dir() and "music" in p.name.lower() and "project" in p.name.lower():
                return p
    except Exception:
        return None
    return None


def google_drive_candidates() -> list[Path]:
    candidates = []
    cloud = HOME / "Library" / "CloudStorage"
    if cloud.exists():
        candidates.extend([p for p in cloud.iterdir() if "GoogleDrive" in p.name or "Google Drive" in p.name])
    for p in [HOME / "Google Drive", Path("/Volumes/GoogleDrive"), Path("/Volumes/Google Drive")]:
        if p.exists():
            candidates.append(p)
    # de-duplicate
    seen = set()
    unique = []
    for p in candidates:
        rp = str(p.resolve()) if p.exists() else str(p)
        if rp not in seen:
            seen.add(rp)
            unique.append(p)
    return unique


def iter_relevant_files(root: Path) -> Iterable[Path]:
    if not root or not root.exists():
        return
    for dirpath, dirnames, filenames in os.walk(root):
        dpath = Path(dirpath)
        if path_is_excluded(dpath):
            dirnames[:] = []
            continue
        # prune hidden/system-ish folders but leave normal project folders
        dirnames[:] = [d for d in dirnames if not d.startswith(".") or d in {".config"}]
        for fn in filenames:
            p = dpath / fn
            if p.suffix.lower() in RELEVANT_EXTS and not path_is_excluded(p):
                yield p


def index_paths(name: str, roots: list[Path]) -> Path:
    rows = []
    for root in roots:
        if root and root.exists():
            safe_print(f"Indexing {name}: {root}")
            for p in iter_relevant_files(root):
                rows.append(stat_row(p))
    out = EXPORT / "indexes" / f"{name}.tsv"
    write_tsv(out, rows, ["modified", "size_bytes", "path"])
    return out


class TextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.skip_stack: list[str] = []
        self.parts: list[str] = []

    def handle_starttag(self, tag, attrs):
        if tag in {"script", "style", "noscript", "svg"}:
            self.skip_stack.append(tag)
        if tag in {"p", "br", "div", "section", "article", "header", "footer", "li", "h1", "h2", "h3"}:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if self.skip_stack and self.skip_stack[-1] == tag:
            self.skip_stack.pop()
        if tag in {"p", "div", "section", "article", "li", "h1", "h2", "h3"}:
            self.parts.append("\n")

    def handle_data(self, data):
        if not self.skip_stack:
            data = data.strip()
            if data:
                self.parts.append(data + " ")

    def get_text(self) -> str:
        text = html.unescape("".join(self.parts))
        text = re.sub(r"\n\s*\n\s*\n+", "\n\n", text)
        text = re.sub(r"[ \t]+", " ", text)
        return text.strip()


def slugify(s: str) -> str:
    s = re.sub(r"^https?://", "", s)
    s = re.sub(r"[^A-Za-z0-9._-]+", "_", s)
    return s.strip("_")[:160] or "url"


def fetch_url(url: str, timeout: int = 30) -> Optional[bytes]:
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X) AppleWebKit/605.1.15 Safari/605.1.15"
        })
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read()
    except Exception as exc:
        return f"FAILED TO FETCH {url}: {exc}".encode("utf-8")


def extract_meta(html_text: str, url: str) -> dict:
    def first(pattern: str) -> str:
        m = re.search(pattern, html_text, re.I | re.S)
        return html.unescape(m.group(1).strip()) if m else ""
    return {
        "url": url,
        "title": first(r"<title[^>]*>(.*?)</title>"),
        "description": first(r'<meta[^>]+name=["\']description["\'][^>]+content=["\'](.*?)["\']'),
        "og_title": first(r'<meta[^>]+property=["\']og:title["\'][^>]+content=["\'](.*?)["\']'),
        "og_description": first(r'<meta[^>]+property=["\']og:description["\'][^>]+content=["\'](.*?)["\']'),
        "og_image": first(r'<meta[^>]+property=["\']og:image["\'][^>]+content=["\'](.*?)["\']'),
        "twitter_title": first(r'<meta[^>]+name=["\']twitter:title["\'][^>]+content=["\'](.*?)["\']'),
        "twitter_description": first(r'<meta[^>]+name=["\']twitter:description["\'][^>]+content=["\'](.*?)["\']'),
    }


def load_social_urls() -> list[str]:
    if not SOCIAL_URLS_FILE.exists():
        return []
    urls = []
    for line in SOCIAL_URLS_FILE.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "PUT_LUKE_WABRO_PERSONAL_HANDLE_HERE" in line:
            continue
        urls.append(line)
    return urls


def export_social() -> Path:
    urls = load_social_urls()
    combined = EXPORT / "social" / "WABRO_SOCIAL_COMBINED_TEXT.txt"
    with combined.open("w", encoding="utf-8") as c:
        c.write(f"WABRO SOCIAL EXPORT\nGenerated: {now_stamp()}\n\n")
        for url in urls:
            safe_print(f"Fetching social URL: {url}")
            slug = slugify(url)
            data = fetch_url(url) or b""
            html_path = EXPORT / "social" / "html" / f"{slug}.html"
            html_path.write_bytes(data)
            html_text = data.decode("utf-8", errors="ignore")

            extractor = TextExtractor()
            try:
                extractor.feed(html_text)
                text = extractor.get_text()
            except Exception as exc:
                text = f"FAILED TO PARSE HTML: {exc}"

            text_path = EXPORT / "social" / "text" / f"{slug}.txt"
            text_path.write_text(text + "\n", encoding="utf-8")

            meta = extract_meta(html_text, url)
            meta_path = EXPORT / "social" / "json" / f"{slug}.metadata.json"
            meta_path.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")

            c.write("==============================\n")
            c.write(f"URL: {url}\n")
            c.write("--- METADATA ---\n")
            c.write(json.dumps(meta, indent=2, ensure_ascii=False) + "\n")
            c.write("--- TEXT ---\n")
            c.write(text[:100000] + "\n\n")

            if "soundcloud.com" in url:
                encoded = urllib.parse.quote(url, safe="")
                oembed_url = f"https://soundcloud.com/oembed?format=json&url={encoded}"
                odata = fetch_url(oembed_url) or b""
                oembed_path = EXPORT / "social" / "json" / f"{slug}.soundcloud_oembed.json"
                oembed_path.write_bytes(odata)
                c.write("--- SOUNDCLOUD OEMBED ---\n")
                c.write(odata.decode("utf-8", errors="ignore")[:50000] + "\n\n")
    return combined


def bitwig_entries(project: Path) -> tuple[list[str], list[tuple[str, str]]]:
    try:
        with zipfile.ZipFile(project, "r") as z:
            names = z.namelist()
            interesting = []
            for name in names:
                lname = name.lower()
                if any(k in lname for k in ["project", "plugin", "device", "track", "automation", "modulator", "metadata"]):
                    interesting.append(name)
                elif lname.endswith((".xml", ".json", ".txt", ".metadata")):
                    interesting.append(name)
            snippets = []
            for name in interesting[:80]:
                try:
                    raw = z.read(name)[:200000]
                    txt = raw.decode("utf-8", errors="ignore")
                    # suppress mostly-binary garbage
                    printable_ratio = sum(ch.isprintable() or ch in "\n\r\t" for ch in txt) / max(len(txt), 1)
                    if printable_ratio > 0.75:
                        snippets.append((name, txt))
                except Exception:
                    pass
            return names[:400], snippets
    except zipfile.BadZipFile:
        return ["Not a readable zip archive"], []
    except Exception as exc:
        return [f"ERROR: {exc}"], []


def export_bitwig(project_roots: list[Path]) -> Path:
    out = EXPORT / "bitwig" / "BITWIG_PROJECTS_COMBINED_TEXT.txt"
    with out.open("w", encoding="utf-8") as f:
        f.write(f"BITWIG PROJECTS COMBINED TEXT\nGenerated: {now_stamp()}\n\n")
        projects: list[Path] = []
        for root in project_roots:
            if root and root.exists():
                projects.extend([p for p in root.rglob("*.bwproject") if not path_is_excluded(p)])
        projects = sorted(projects, key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
        for project in projects[:200]:
            safe_print(f"Extracting Bitwig metadata: {project.name}")
            f.write("==============================\n")
            f.write(f"BITWIG PROJECT: {project}\n")
            f.write("==============================\n")
            f.write(f"STAT: {stat_row(project)}\n\n")
            names, snippets = bitwig_entries(project)
            f.write("--- ARCHIVE ENTRY LIST / FIRST 400 ---\n")
            for name in names:
                f.write(f"{name}\n")
            f.write("\n--- READABLE SNIPPETS ---\n")
            for name, txt in snippets:
                f.write(f"\n----- ENTRY: {name} -----\n")
                f.write(txt[:200000])
                f.write("\n")
            f.write("\n")
    return out


def export_eeg_and_patches(roots: list[Path]) -> Path:
    out = EXPORT / "eeg" / "EEG_PATCHES_AND_CHAIN_COMBINED_TEXT.txt"
    with out.open("w", encoding="utf-8") as f:
        f.write(f"WABRO EEG / PLUGDATA / BITWIG CHAIN\nGenerated: {now_stamp()}\n\n")
        f.write("""Core chain:\n\nEEG headset / Muse / Mind Monitor\n↓\nOSC / UDP / MIDI stream\n↓\nPython or PlugData\n↓\nAlpha / Beta / Delta / Gamma / Theta + Gyroscope\n↓\nSmoothing / normalisation / emotion-macro formulas\n↓\nMIDI CC or OSC\n↓\nBitwig macros + TouchDesigner visuals\n\nRecommended macro set:\nCC1 Focus\nCC2 Tension\nCC3 Calm\nCC4 Weight\nCC5 Spark\nCC6 Instability\nCC7 Mutation\nCC8 Gesture\nCC9 Grief/Darkness\nCC10 Relaxation\nCC11 Wonder\nCC12 Arousal\n\n""")
        patch_files: list[Path] = []
        for root in roots:
            if root and root.exists():
                for p in root.rglob("*"):
                    if p.is_file() and (p.suffix.lower() in PATCH_EXTS or any(k in p.name.lower() for k in ["eeg", "muse", "mind", "plugdata"])) and not path_is_excluded(p):
                        patch_files.append(p)
        for p in sorted(set(patch_files))[:300]:
            f.write("==============================\n")
            f.write(f"FILE: {p}\n")
            f.write("==============================\n")
            try:
                raw = p.read_bytes()[:300000]
                txt = raw.decode("utf-8", errors="ignore")
                if p.suffix.lower() in {".pd", ".maxpat", ".txt", ".json", ".xml", ".md"}:
                    f.write(txt)
                else:
                    f.write("Binary/opaque patch or device. Indexed only.\n")
            except Exception as exc:
                f.write(f"ERROR READING FILE: {exc}\n")
            f.write("\n\n")
    return out


def extract_audio(video: Path, audio_out: Path) -> bool:
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        return False
    audio_out.parent.mkdir(parents=True, exist_ok=True)
    cmd = [ffmpeg, "-y", "-i", str(video), "-vn", "-ac", "1", "-ar", "16000", str(audio_out)]
    try:
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True, timeout=1800)
        return audio_out.exists() and audio_out.stat().st_size > 0
    except Exception:
        return False


def transcribe_audio(audio: Path, transcript_out: Path) -> bool:
    whisper = shutil.which("whisper")
    if not whisper:
        return False
    transcript_out.parent.mkdir(parents=True, exist_ok=True)
    out_dir = transcript_out.parent
    cmd = [
        whisper, str(audio),
        "--model", "base",
        "--language", "English",
        "--task", "transcribe",
        "--output_format", "txt",
        "--output_dir", str(out_dir),
    ]
    try:
        subprocess.run(cmd, check=True, timeout=7200)
        generated = out_dir / f"{audio.stem}.txt"
        if generated.exists():
            if generated != transcript_out:
                generated.replace(transcript_out)
            return True
    except Exception:
        return False
    return False


def export_videos(video_roots: list[Path]) -> Path:
    index_rows = []
    videos: list[Path] = []
    for root in video_roots:
        if root and root.exists():
            safe_print(f"Scanning videos: {root}")
            for p in iter_relevant_files(root):
                if p.suffix.lower() in VIDEO_EXTS:
                    videos.append(p)
                    index_rows.append(stat_row(p))
    write_tsv(EXPORT / "videos" / "video_index.tsv", index_rows, ["modified", "size_bytes", "path"])

    combined = EXPORT / "transcripts" / "VIDEO_TRANSCRIPTS_COMBINED_TEXT.txt"
    with combined.open("w", encoding="utf-8") as f:
        f.write(f"VIDEO TRANSCRIPTS COMBINED TEXT\nGenerated: {now_stamp()}\n\n")
        f.write(f"ffmpeg found: {bool(shutil.which('ffmpeg'))}\n")
        f.write(f"whisper found: {bool(shutil.which('whisper'))}\n\n")
        for i, video in enumerate(sorted(videos, key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)[:100], start=1):
            safe_print(f"Processing video {i}/{min(len(videos),100)}: {video.name}")
            slug = re.sub(r"[^A-Za-z0-9._-]+", "_", video.stem)[:120]
            audio_out = EXPORT / "audio_extracts" / f"{slug}.wav"
            transcript_out = EXPORT / "transcripts" / f"{slug}.txt"
            f.write("==============================\n")
            f.write(f"VIDEO: {video}\n")
            f.write(f"STAT: {stat_row(video)}\n")

            if not transcript_out.exists():
                if extract_audio(video, audio_out):
                    f.write(f"AUDIO_EXTRACT: {audio_out}\n")
                    if transcribe_audio(audio_out, transcript_out):
                        f.write(f"TRANSCRIPT: {transcript_out}\n")
                    else:
                        f.write("TRANSCRIPT: not created. Install whisper with: python3 -m pip install -U openai-whisper\n")
                else:
                    f.write("AUDIO_EXTRACT: not created. Install ffmpeg with: brew install ffmpeg\n")

            if transcript_out.exists():
                f.write("--- TRANSCRIPT TEXT ---\n")
                f.write(transcript_out.read_text(encoding="utf-8", errors="ignore")[:250000])
                f.write("\n")
            f.write("\n")
    return combined


def combine_master(files: list[Path], environment_summary: dict) -> Path:
    out = EXPORT / "WABRO_MASTER_TEXT_FOR_CHATGPT.txt"
    with out.open("w", encoding="utf-8") as f:
        f.write("WABRO MASTER TEXT FOR CHATGPT\n")
        f.write(f"Generated: {now_stamp()}\n\n")
        f.write("ENVIRONMENT SUMMARY\n")
        f.write(json.dumps(environment_summary, indent=2, ensure_ascii=False))
        f.write("\n\n")
        for file in files:
            if not file or not file.exists():
                continue
            f.write("==============================\n")
            f.write(f"FILE: {file}\n")
            f.write("==============================\n")
            try:
                f.write(file.read_text(encoding="utf-8", errors="ignore")[:1000000])
            except Exception as exc:
                f.write(f"ERROR READING: {exc}\n")
            f.write("\n\n")
    return out


def zip_export() -> Optional[Path]:
    zip_path = DESKTOP / "WABRO_FULL_PROJECT_EXPORT.zip"
    try:
        if zip_path.exists():
            zip_path.unlink()
        shutil.make_archive(str(zip_path.with_suffix("")), "zip", root_dir=DESKTOP, base_dir=EXPORT.name)
        return zip_path
    except Exception as exc:
        safe_print(f"Could not zip export folder: {exc}")
        return None


def main() -> int:
    ensure_dirs()
    safe_print("WABRO Full Project Exporter")
    safe_print(f"Export folder: {EXPORT}")
    safe_print("")

    backup = find_backup_drive()
    music_projects = find_music_projects(backup)
    gdrives = google_drive_candidates()

    roots_for_all = []
    if music_projects:
        roots_for_all.append(music_projects)
    elif backup:
        roots_for_all.append(backup)
    roots_for_all.extend(gdrives)

    env = {
        "generated": now_stamp(),
        "backup_drive": str(backup) if backup else None,
        "music_projects_folder": str(music_projects) if music_projects else None,
        "google_drive_candidates": [str(p) for p in gdrives],
        "ffmpeg_found": bool(shutil.which("ffmpeg")),
        "whisper_found": bool(shutil.which("whisper")),
        "export_folder": str(EXPORT),
    }

    created: list[Path] = []

    # Focused indexes.
    if music_projects:
        created.append(index_paths("music_projects_relevant_file_index", [music_projects]))
    if backup:
        # This can be large, but only relevant extensions.
        created.append(index_paths("lukes_backups_relevant_file_index", [backup]))
    if gdrives:
        created.append(index_paths("google_drive_relevant_file_index", gdrives))

    # Social public pages.
    created.append(export_social())

    # Bitwig readable extraction.
    bitwig_roots = [p for p in [music_projects, backup] if p]
    if bitwig_roots:
        created.append(export_bitwig(bitwig_roots))

    # EEG/Patch export.
    eeg_roots = [p for p in [music_projects, backup] if p]
    eeg_roots.extend(gdrives)
    if eeg_roots:
        created.append(export_eeg_and_patches(eeg_roots))

    # Video index/transcripts from Google Drive and backup/music projects.
    video_roots = []
    video_roots.extend(gdrives)
    if music_projects:
        video_roots.append(music_projects)
    if video_roots:
        created.append(export_videos(video_roots))

    master = combine_master(created, env)
    z = zip_export()

    safe_print("")
    safe_print("DONE")
    safe_print(f"Upload this first: {master}")
    if z:
        safe_print(f"Or upload the zip: {z}")
    safe_print("")
    safe_print("If video transcripts are missing, install transcription support:")
    safe_print("  brew install ffmpeg")
    safe_print("  python3 -m pip install -U openai-whisper")
    safe_print("Then rerun this script.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# WABRO Full Project Export Toolkit

This toolkit turns your WABRO-related local folders into text data that can be uploaded to ChatGPT.

It can index and export:

- Google Drive videos, if Google Drive is synced/downloaded locally
- videos/audio into transcript text, if `ffmpeg` and `whisper` are installed
- Bitwig `.bwproject` project metadata/text
- Ableton/Max/PlugData/Pure Data file indexes
- the `Music Projects` folder on `Lukes backups`
- social-media public page metadata/text
- EEG / PlugData / Bitwig chain files
- one combined master text file for ChatGPT

It does **not** use passwords, cookies, browser history, hidden login sessions, bank files, private messages, or system keychains.

## Quick start

1. Open Terminal.
2. Unzip this folder to your Desktop.
3. Run:

```bash
cd ~/Desktop/wabro_full_project_toolkit
chmod +x scripts/run_wabro_full_project.command
./scripts/run_wabro_full_project.command
```

When it finishes, upload:

```text
~/Desktop/WABRO_FULL_PROJECT_EXPORT/WABRO_MASTER_TEXT_FOR_CHATGPT.txt
```

or zip/upload the whole folder:

```text
~/Desktop/WABRO_FULL_PROJECT_EXPORT
```

## Optional transcription install

The script can still create video indexes without transcription. For local transcription, install:

```bash
brew install ffmpeg
python3 -m pip install -U openai-whisper
```

Then rerun the script. It will use the `whisper` command-line tool if found.

## Personal Instagram

Edit this file if you want to add your personal Luke Wabro Instagram URL:

```text
config/social_urls.txt
```

Replace:

```text
https://www.instagram.com/PUT_LUKE_WABRO_PERSONAL_HANDLE_HERE/
```

with the actual profile URL.

#!/bin/bash

# WABRO / Assemblage public social data exporter
# Saves public HTML, readable text, metadata, and SoundCloud oEmbed data.
# It does NOT use passwords, cookies, or private login sessions.

EXPORT="$HOME/Desktop/WABRO_SOCIAL_EXPORT"
mkdir -p "$EXPORT/html" "$EXPORT/text" "$EXPORT/json"

URLS=(
  "https://soundcloud.com/wabro_official"
  "https://soundcloud.com/assemblage-recordings"
  "https://github.com/WABRODNB"
  "https://github.com/assemblagerecordings"
  "https://www.youtube.com/channel/UCl7ODE89K1UzrBCSQTDXS6Q"
  "https://www.youtube.com/@AssemblageRecordings"
  "https://www.instagram.com/wabro_dnb/"
  "https://www.instagram.com/assemblagerecordings/"
  "https://wabro.bandcamp.com"
  "https://assemblagerecordings.bandcamp.com"
  "https://lukewabro7.wixsite.com/wabro"
  "https://lukewabro7.wixsite.com/assemblagerecordings"
)

slugify() {
  echo "$1" | sed 's#https\?://##' | sed 's#[/:?&=%]+#_#g' | sed 's#[^A-Za-z0-9._-]#_#g'
}

strip_html_to_text() {
  python3 - "$1" "$2" <<'PY'
import re
import sys
from html import unescape
from html.parser import HTMLParser

src, dst = sys.argv[1], sys.argv[2]

class Extractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.skip = False
        self.parts = []

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style", "noscript", "svg"):
            self.skip = True
        if tag in ("p", "br", "div", "section", "article", "header", "footer", "li", "h1", "h2", "h3"):
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag in ("script", "style", "noscript", "svg"):
            self.skip = False
        if tag in ("p", "div", "section", "article", "li", "h1", "h2", "h3"):
            self.parts.append("\n")

    def handle_data(self, data):
        if not self.skip:
            data = data.strip()
            if data:
                self.parts.append(data + " ")

try:
    html = open(src, "r", encoding="utf-8", errors="ignore").read()
    parser = Extractor()
    parser.feed(html)
    text = unescape("".join(parser.parts))
    text = re.sub(r"\n\s*\n\s*\n+", "\n\n", text)
    text = re.sub(r"[ \t]+", " ", text)
    open(dst, "w", encoding="utf-8").write(text.strip() + "\n")
except Exception as e:
    open(dst, "w", encoding="utf-8").write(f"FAILED TO PARSE: {e}\n")
PY
}

extract_meta() {
  python3 - "$1" "$2" "$3" <<'PY'
import json
import re
import sys
from html import unescape

url, html_path, out_path = sys.argv[1], sys.argv[2], sys.argv[3]
html = open(html_path, "r", encoding="utf-8", errors="ignore").read()

def first(pattern):
    m = re.search(pattern, html, re.I | re.S)
    return unescape(m.group(1).strip()) if m else ""

data = {
    "url": url,
    "title": first(r"<title[^>]*>(.*?)</title>"),
    "description": first(r'<meta[^>]+name=["\']description["\'][^>]+content=["\'](.*?)["\']'),
    "og_title": first(r'<meta[^>]+property=["\']og:title["\'][^>]+content=["\'](.*?)["\']'),
    "og_description": first(r'<meta[^>]+property=["\']og:description["\'][^>]+content=["\'](.*?)["\']'),
    "og_image": first(r'<meta[^>]+property=["\']og:image["\'][^>]+content=["\'](.*?)["\']'),
    "twitter_title": first(r'<meta[^>]+name=["\']twitter:title["\'][^>]+content=["\'](.*?)["\']'),
    "twitter_description": first(r'<meta[^>]+name=["\']twitter:description["\'][^>]+content=["\'](.*?)["\']'),
}

open(out_path, "w", encoding="utf-8").write(json.dumps(data, indent=2, ensure_ascii=False))
PY
}

echo "Export folder:"
echo "$EXPORT"
echo ""

for url in "${URLS[@]}"; do
  slug="$(slugify "$url")"
  html_file="$EXPORT/html/${slug}.html"
  text_file="$EXPORT/text/${slug}.txt"
  meta_file="$EXPORT/json/${slug}.metadata.json"

  echo "Fetching: $url"

  curl -L \
    --compressed \
    --max-time 30 \
    --retry 2 \
    -A "Mozilla/5.0 (Macintosh; Intel Mac OS X) AppleWebKit/605.1.15 Safari/605.1.15" \
    "$url" \
    -o "$html_file" \
    2>/dev/null

  if [ -s "$html_file" ]; then
    strip_html_to_text "$html_file" "$text_file"
    extract_meta "$url" "$html_file" "$meta_file"
  else
    echo "FAILED TO FETCH: $url" > "$text_file"
  fi

  # SoundCloud public oEmbed metadata
  if [[ "$url" == *"soundcloud.com"* ]]; then
    encoded_url="$(python3 -c 'import urllib.parse,sys; print(urllib.parse.quote(sys.argv[1], safe=""))' "$url")"
    curl -L \
      --max-time 30 \
      "https://soundcloud.com/oembed?format=json&url=${encoded_url}" \
      -o "$EXPORT/json/${slug}.soundcloud_oembed.json" \
      2>/dev/null
  fi
done

# Build one combined text file for ChatGPT
COMBINED="$EXPORT/WABRO_SOCIAL_COMBINED_TEXT.txt"
echo "WABRO / ASSEMBLAGE SOCIAL EXPORT" > "$COMBINED"
echo "Generated: $(date)" >> "$COMBINED"
echo "" >> "$COMBINED"

for file in "$EXPORT"/json/*.json "$EXPORT"/text/*.txt; do
  [ -e "$file" ] || continue
  echo "==============================" >> "$COMBINED"
  echo "FILE: $file" >> "$COMBINED"
  echo "==============================" >> "$COMBINED"
  cat "$file" >> "$COMBINED"
  echo "" >> "$COMBINED"
done

# Zip everything for upload
cd "$HOME/Desktop" || exit 1
zip -r "WABRO_SOCIAL_EXPORT.zip" "WABRO_SOCIAL_EXPORT" >/dev/null

echo ""
echo "Done."
echo "Upload this file to ChatGPT:"
echo "$HOME/Desktop/WABRO_SOCIAL_EXPORT.zip"
echo ""
echo "Or upload just this combined text file:"
echo "$COMBINED"

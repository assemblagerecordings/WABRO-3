import os
from datetime import datetime
from pathlib import Path

try:
    from openai import OpenAI
except ImportError:
    print("OpenAI library is not installed.")
    print("Run this in Terminal:")
    print("python3 -m pip install openai")
    raise SystemExit


DESKTOP = Path.home() / "Desktop"
ROOT = DESKTOP / "WABRO_OS"

MASTER = ROOT / "00_MASTER_CONTROL"
LOGS = MASTER / "COUNCIL_LOGS"

MASTER.mkdir(parents=True, exist_ok=True)
LOGS.mkdir(parents=True, exist_ok=True)

MASTER_FILE = MASTER / "WABRO_PROJECT_OS.md"

if not MASTER_FILE.exists():
    MASTER_FILE.write_text("""
# WABRO PROJECT OS

WABRO = Electronic Music as an Open System.

Core pillars:
1. Sound engine
2. Muse 2 / brainwave control
3. Bitwig / Max / Pure Data / OSC / MIDI
4. Visual engine
5. Research and theory
6. Release strategy
7. Assemblage Recordings
8. Future platform

Main rule:
Every AI should improve the project, not only answer the question.
""")


def load_context():
    texts = []
    for file in MASTER.glob("*.md"):
        texts.append(f"\n--- {file.name} ---\n")
        texts.append(file.read_text(errors="ignore"))
    return "\n".join(texts)


COUNCIL = {
    "Core Architect": "Unify the whole WABRO system and create practical next steps.",
    "Sound Design AI": "Improve snare, bass, drums, neurofunk production, Bitwig chains, clipping, saturation, and Muse control.",
    "Visual Engine AI": "Turn sound, waveform, Muse data, and performance states into visual systems.",
    "Research AI": "Connect the project to assemblage theory, rhizomes, sound-object theory, postmodernism, and human-machine creativity.",
    "Release Manager AI": "Improve EPKs, release plans, GitHub README files, Bandcamp, SoundCloud, YouTube, and Assemblage strategy.",
    "Codex Builder": "Turn the idea into code, terminal tasks, folder structures, APIs, MIDI/OSC tools, and prototypes.",
    "Future WABRO": "Ask what the project becomes if it succeeds beyond expectations."
}


def ask_ai(client, role, role_instruction, question, context, previous):
    prompt = f"""
You are {role}.

Role instruction:
{role_instruction}

WABRO context:
{context}

User question:
{question}

Previous council discussion:
{previous}

Reply using this format:

### Assessment
### Improvements
### Concrete Tasks
### Files To Create Or Update
### Message To The Next AI
"""

    response = client.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[
            {"role": "system", "content": f"You are {role} for the WABRO AI Council."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.7
    )

    return response.choices[0].message.content


def main():
    api_key = os.getenv("OPENAI_API_KEY")

    if not api_key:
        print("No OpenAI API key found.")
        print("Run this first:")
        print('export OPENAI_API_KEY="paste_your_api_key_here"')
        return

    client = OpenAI(api_key=api_key)

    print("\nWABRO COUNCIL ONLINE")
    print("Folder:", ROOT)
    print("Logs:", LOGS)

    question = input("\nWhat should WABRO work on? ")

    context = load_context()
    previous = ""
    full_log = []

    for role, instruction in COUNCIL.items():
        print(f"\nAsking {role}...\n")
        answer = ask_ai(client, role, instruction, question, context, previous)

        section = f"\n\n# {role}\n\n{answer}\n"
        full_log.append(section)
        previous += section

    print("\nCreating final synthesis...\n")

    synthesis = ask_ai(
        client,
        "Final Council Synthesis",
        "Combine all council responses into one clear decision and action plan.",
        question,
        context,
        previous
    )

    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    output_file = LOGS / f"WABRO_COUNCIL_{timestamp}.md"

    output_file.write_text(
        "# WABRO Council Log\n\n"
        f"Date: {timestamp}\n\n"
        f"Question: {question}\n\n"
        "---\n\n"
        "# Council Discussion\n\n"
        + "\n".join(full_log)
        + "\n\n---\n\n"
        "# Final Synthesis\n\n"
        + synthesis
    )

    print("\nDONE.")
    print("Council log saved here:")
    print(output_file)


if __name__ == "__main__":
    main()
# WABRO 3 AI GitHub Export

This is a GitHub-safe, AI-readable export of `/Users/lukewabro/Desktop/WABRO 3`.

The original folder was not modified. Heavy media, renders, stems, plugin installers, archives, app bundles, screenshots, PDFs, Word/RTF files, and binary/plugin formats were excluded.

## How AIs Should Read This Folder

1. Start with `WABRO_3_EXPORT_REPORT.md`.
2. Read `WABRO_3_STRUCTURE.txt` to understand the folder shape.
3. Read core WABRO docs first: master context, memory, tasks, macros, graph, state, and index files.
4. Read `tools/` and code/patch files second.
5. Use `WABRO_3_AI_EXPORT.txt` as a single combined context file when an AI system cannot browse folders.

## Project Orientation

WABRO 3 is an AI-readable working export for WABRO X ASSEMBLAGE: Luke WABRO's state-responsive electronic music instrument and archive system.

Current priority:

```text
Instrument -> Knowledge Graph -> Platform
```

Do not design the platform first. Build and understand the instrument layer first:

```text
Backwards V5 + Muse 2/simulator + 8 macros + snare geometry + persistent state
```

## Included File Policy

Included extensions:

```text
.md .txt .json .jsonl .py .js .ts .html .css .xml .csv .tsv .pd .maxpat .sh .command
```

Included files are source-like, documentation-like, data-like, or patch-like files suitable for GitHub and AI reading.


# WABRO X ASSEMBLAGE — CODEX INSTRUCTIONS

## Core Rule

Design this system the way Luke designs a snare.

A good snare is not one sound. It is a controlled relationship between:

1. Fundamental
2. Body
3. Transient
4. Noise
5. Harmonic colour
6. Spectral movement
7. Safety / gain control

The WABRO EEG system must be designed the same way.

Do not build random EEG-to-MIDI chaos.
Build a layered, playable instrument.

---

## Translation

### Snare Fundamental = Stable State

The system needs a stable centre.

Build:
- WABRO_STATE.json
- state_server.py
- stable state names: Signal, Pressure, Mutation, Collapse

The state file is the fundamental pitch of the whole system.

---

### Snare Body = Smoothing

Raw EEG is too unstable.

Build:
- moving average smoothing
- exponential smoothing
- minimum/maximum value limits
- readable macro ranges from 0.0 to 1.0

The system should breathe, not twitch.

---

### Snare Transient = Intentional Triggers

Use sudden events carefully.

Inputs:
- blink
- jaw clench
- strong movement
- sudden beta/gamma spike

Map these to intentional triggers:
- fill
- glitch
- scene change
- collapse burst

Do not let transient events constantly retrigger.

Use cooldown timers.

---

### Snare Noise = Controlled Chaos

Noise is useful when shaped.

Mutation and Collapse should control:
- glitch probability
- spectral deformation
- visual fragmentation
- resampling amount

But keep them bounded.

Chaos must be performable.

---

### Harmonic Layer = Musical Meaning

Map EEG states to musical behaviours, not random parameters.

Signal:
- clarity
- width
- clean geometry
- snare fundamental up
- noise down

Pressure:
- snare noise up
- transient bite up
- bass distortion up
- filter drive up

Mutation:
- spectral rotation up
- FM/resampling up
- visual deformation up

Collapse:
- glitch up
- fragmentation up
- buffer jumps up
- master intensity capped

---

### Spectral Movement = The WABRO Signature

The main artistic goal is not EEG-to-MIDI.

The goal is:

EEG -> State Engine -> Snare Layer Morphing + Spectral Rotation -> Bitwig + Visuals

Prioritise:
- spectral rotation macro
- snare layer morphing
- bass aggression
- visual deformation
- shared audio/visual state

---

### Safety Layer = Master Chain

Never allow the system to destroy the mix.

Implement:
- macro clamps
- master intensity ceiling
- collapse timeout
- fallback to Signal state
- logging of state changes

Python safety comes first.
Bitwig safety comes second.

---

## Build Target

Create a local WABRO state bridge:

Muse 2 or mock EEG
-> Python feature input
-> smoothing
-> state momentum
-> state classifier
-> safety layer
-> WABRO_STATE.json
-> HTTP endpoint
-> OSC output
-> Bitwig / TouchDesigner / Blender / agents

---

## Files To Maintain

Use this folder as the WABRO control room:

/Users/lukewabro/Documents/WABRO

Maintain:
- WABRO_STATE.json
- WABRO_TASKS.md
- WABRO_MEMORY.md
- WABRO_LOG.jsonl
- WABRO_BUILD_SPEC.md
- WABRO_MASTER_SPEC.md

---

## First Working Demo

The first demo is not a platform.

The first demo is:

Muse 2 controls a Bitwig neurofunk rack and one visual scene in real time.

Success criteria:
- state changes are visible
- macros are stable
- snare/bass/visuals respond coherently
- collapse cannot wreck the mix
- a 3-5 minute performance can be recorded

---

## Current Priority

Build the instrument first.
Platform later.

Do not scan the whole archive unless asked.
Do not build social media features yet.
Do not over-engineer.

Make one playable living instrument.

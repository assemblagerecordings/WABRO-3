# WABRO Project Graph

Updated: 2026-06-02T16:15:01

## Summary

- Nodes: 43
- Edges: 39

## Node Types

- ArchitectureLayer: 3
- Asset: 4
- CoreScript: 3
- CreativeObject: 1
- DataStream: 1
- EEGMapping: 1
- FileState: 1
- Hardware: 1
- MacroMapping: 1
- Project: 1
- Render: 3
- SnareLayer: 6
- Software: 2
- Track: 7
- Version: 7
- VisualMapping: 1

## Demo 0.1 Links

- `layer_1_instrument` -> `layer_2_graph` (PRE_REQUISITE_FOR)
- `layer_2_graph` -> `layer_3_platform` (PRE_REQUISITE_FOR)
- `hw_muse2` -> `script_hub` (PROVIDES_RAW_TELEMETRY)
- `script_hub` -> `sw_bitwig` (DRIVES_MACROS_VIA_OSC)
- `data_macro_values` -> `sw_bitwig` (DRIVES_MACROS_VIA_OSC)
- `script_hub` -> `file_state` (RECORDS_STATE_INTO)
- `track_backwards` -> `layer_1_instrument` (SERVES_AS_INITIAL_MUTATION_TARGET)
- `track_backwards` -> `version_backwards_v5` (HAS_VERSION)
- `track_back_and_fourth` -> `version_back_and_fourth_v6` (HAS_VERSION)
- `track_carnage` -> `version_carnage_unverified` (HAS_VERSION)
- `track_underground` -> `version_underground_unverified` (HAS_VERSION)
- `track_gentle_whisper` -> `version_gentle_whisper_unverified` (HAS_VERSION)
- `track_synchronicity` -> `version_synchronicity_unverified` (HAS_VERSION)
- `track_interpolation` -> `version_interpolation_v2` (HAS_VERSION)
- `version_carnage_unverified` -> `render_carnage_sf_v2` (GENERATED_RENDER)
- `version_underground_unverified` -> `render_underground_sf_v2` (GENERATED_RENDER)
- `version_gentle_whisper_unverified` -> `render_gentle_whisper_sf_v5` (GENERATED_RENDER)
- `version_backwards_v5` -> `macro_mapping_demo_0_1` (BINDS_MACRO)
- `eeg_mapping_muse2_to_hub` -> `macro_mapping_demo_0_1` (DRIVES_STREAM)
- `macro_mapping_demo_0_1` -> `visual_mapping_snare_geometry` (MUTATES_GEOMETRY)
- `version_backwards_v5` -> `asset_dir_projects` (INSTANTIATED_BY)
- `version_back_and_fourth_v6` -> `asset_dir_projects` (INSTANTIATED_BY)
- `version_interpolation_v2` -> `asset_dir_uni` (INSTANTIATED_BY)
- `obj_snare_system` -> `snare_fundamental` (CONTAINS_SUB_ELEMENT)
- `obj_snare_system` -> `snare_harmonic` (CONTAINS_SUB_ELEMENT)
- `obj_snare_system` -> `snare_noise_1` (CONTAINS_SUB_ELEMENT)
- `obj_snare_system` -> `snare_noise_2` (CONTAINS_SUB_ELEMENT)
- `obj_snare_system` -> `snare_acoustic` (CONTAINS_SUB_ELEMENT)
- `obj_snare_system` -> `snare_transient` (CONTAINS_SUB_ELEMENT)

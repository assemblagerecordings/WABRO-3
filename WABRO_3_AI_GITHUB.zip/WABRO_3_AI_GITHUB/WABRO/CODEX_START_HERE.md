# CODEX START HERE

Read AGENTS.md first.

Your first task:

Build or repair the local WABRO state bridge.

The system should run with mock EEG first, then Muse 2 later.

Required outputs:
1. WABRO_STATE.json updates continuously.
2. HTTP endpoint returns current state at http://localhost:8000/state
3. OSC sends /wabro/state and /wabro/macro/1 through /wabro/macro/16
4. WABRO_LOG.jsonl records state changes.
5. WABRO_TASKS.md says what works and what is next.

Design it like Luke designs a snare:
stable fundamental, shaped body, intentional transient, controlled noise, spectral movement, safety limiter.

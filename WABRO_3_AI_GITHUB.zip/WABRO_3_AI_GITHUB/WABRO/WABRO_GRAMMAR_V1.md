# WABRO GRAMMAR PROTOCOL v1.0

Machine-readable intent vectors for the Layer 1 WABRO instrument: neurofunk architecture, EEG control, Bitwig macro routing, snare geometry, and persistent state.

## Production Grammar

- Mutation target constraint: Backwards V5 is treated as the first open-system DNA template, not a fixed track.
- Eight-macro bus: external telemetry is normalized into exactly eight macro values before touching Bitwig, visuals, or state.
- File-level ledger hook: project saves are indexed through filesystem metadata, plugin references, fingerprints, graph updates, state updates, and log events.

## Canonical Macro Bus

| Macro | Current WABRO Name | Role |
| --- | --- | --- |
| 1 | snare_fundamental | Snare body, central polygon scale, low-frequency anchor |
| 2 | snare_noise | High-frequency noise layer, outer particle density |
| 3 | snare_transient_bite | Attack flash, transient edge, visual luminance spike |
| 4 | bass_filter_motion | Bass filter movement and body-density pressure |
| 5 | bass_distortion | Saturation, clipping intensity, internal pressure |
| 6 | spectral_rotation | FFT/spectral mutation, geometric rotation force |
| 7 | space_width | Width, spatial bloom, ring spread |
| 8 | glitch_fill_probability | Fill chance, interruption, mutation probability |

## Snare Ontology

- Transient layer: initial attack spike; controls global flash and sharpness.
- Fundamental layer: center-frequency body; controls central polygon side count and scale.
- Harmonic layer: overtone structure; controls orbiting rings and secondary geometry.
- Noise layer 1: bright texture; controls outer particle halo density and velocity.
- Noise layer 2: diffuse granular texture; controls inner cloud and surface instability.
- Acoustic layer: physical shell resonance; controls wireframe shell, thickness, and deformation.

## Neurofunk Bass Ontology

- Wavetable phase tracking: bass motion is treated as stateful movement rather than a static riff.
- Resampling loops: distortion and clipping intensity can rise with pressure while filter movement remains bounded.
- Sub-bass split: material below 90 Hz should remain mono and protected from width modulation.

## Visual Grammar

- Anti-oscilloscope mandate: the visualiser shows system state, not a literal waveform display.
- Geometric organisms: particles, rings, shells, and polygon cores act as reactive life-form structures.
- Biological interruption maps: EEG pressure and mutation states destabilize symmetry and density.

## Biological Routing

- Muse 2 or simulator enters `wabro_hub.py` as raw features.
- `wabro_hub.py` computes normalized macro values.
- The same macro values drive Bitwig, the dashboard/snare visualiser, OSC subscribers, and `WABRO_STATE.json`.

## Lifecycle Constraint

Layer 1 comes first. Do not build the social platform until the living creative instrument is reliable.

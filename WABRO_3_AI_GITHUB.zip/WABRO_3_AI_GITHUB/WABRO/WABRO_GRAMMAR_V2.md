# WABRO Grammar V2

Demo 0.1 grammar for the living creative instrument.

## Approved Visual Principle

Anti-oscilloscope: build a state visualiser / geometric organism. Do not build a waveform viewer.

## Demo 0.1 Flow

Backwards V5 + Muse 2 + 8 macros + snare geometry + persistent state.

```text
Muse 2 or simulator
  -> wabro_hub.py
  -> MacroMapping: Demo 0.1 Eight Macro Mapping
  -> Bitwig + TouchDesigner/dashboard + WABRO_STATE.json
```

## Eight Macro Bus

1. snare_fundamental
2. snare_noise
3. snare_transient_bite
4. bass_filter_motion
5. bass_distortion
6. spectral_rotation
7. space_width
8. glitch_fill_probability

## Snare Ontology

- Transient
- Fundamental
- Harmonic
- Noise 1
- Noise 2
- Acoustic

## Build Constraint

Layer 1 Instrument before Layer 2 Graph before Layer 3 Platform. V2 graph changes must support Demo 0.1 directly.

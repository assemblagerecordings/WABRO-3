# WABRO Core Ontology V2

This is the lightweight ontology used by the Demo 0.1 graph, watcher, and future mutation engine. It is deliberately small: the full archive belongs in `WABRO_INDEX.jsonl`; the graph tracks only the entities needed to make the instrument work.

## Entities

- Track: stable identity of a musical work across versions.
- Version: specific save-state or project iteration, such as a `.bwproject` or `.als` file.
- Render: full bounce/export of a Version.
- Stem: bounced subgroup or isolated layer from a Version.
- Sample: discrete audio component used by a Version.
- PluginChain: ordered software signal path used inside a Version.
- MacroMapping: binding between real-time input slots and host/software controls.
- EEGMapping: rule mapping Muse/brainwave telemetry to macro streams.
- VisualMapping: rule mapping macro streams to geometry, space, and lighting.

## Relationships

- HAS_VERSION: Track -> Version.
- GENERATED_RENDER: Version -> Render.
- EXPORTS_STEM: Version -> Stem.
- REFERENCES_SAMPLE: Version -> Sample.
- INSTANTIATES_CHAIN: Version -> PluginChain.
- BINDS_MACRO: Version -> MacroMapping.
- DRIVES_STREAM: EEGMapping -> MacroMapping.
- MUTATES_GEOMETRY: MacroMapping -> VisualMapping.
- INSTANTIATED_BY: Version/Render/Stem/Sample -> Asset.

## Integrity Rule

Use `DISCOVERY_REQUIRED` for unverified paths or versions. Do not invent project paths, chain contents, or sample links before the watcher or indexer has observed them.
